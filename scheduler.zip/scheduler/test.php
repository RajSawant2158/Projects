<?php include ('config.php') ?>
<?php include ('inc/header.php') ?>
<?php include ('home.php') ?>