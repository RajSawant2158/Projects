<?php


    mysql_connect("localhost","root","") or die (mysql_error());
    mysql_select_db("votedatabase") or die (mysql_error());

//mysql_query("DELETE * FROM candidate");
//mysql_query("DELETE * FROM votercode");
//mysql_query("DELETE * FROM qrcodenum");


?>
