


    <!-- main content -->
    <div id="content">
      <!-- section 1 -->
	 <section>
        <!-- article 1 -->
        <article>
		<img src="img/company.png" style ="margin-bottom:20px;">
		<div class="clear"></div>
		
          <h2><a href="home.php">Welcome To MCWDEAP</a></h2>
          <address>
          info@MCWDEAP.com
          </address>
           <address>
	Mabalacat City Water District Mabiga, Mabalacat City Pampanga
          </address>
          <p style="    
		font-family:georgia, serif;
	  color:#381704;
	  font-size:14px;
	  letter-spacing:0.1em;
	  line-height:200%;
	  padding-top:11px;
	  text-align:center;">This web site was created to provide an accurate and automated voting system process for the Mabalacat City Water District Employees Assocition for Progress (MCWDEAP) Election .
				If you are a member of the organization , we invite you  to participate in the incoming MCWDEAP election for year 2015-2016.. </p>
        </article>
        <!-- article 2 -->
	   <article>
	   
	   <div class="clear"></div>
  </div>
          <h2><a href="#">About</a></h2>
          
        
          <p style="    
		font-family:georgia, serif;
	  color:#381704;
	  font-size:14px;
	  letter-spacing:0.1em;
	  line-height:200%;
	  padding-top:11px;
	  ">The Mabalacat City Water District Employees Association for Progress (MCWDEAP) has taken on the spirit of cityhood where it finds home. Formerly sporting the same initials except for the letter C, the association has added the term "city" to its name and thus C to its initials.<a href="http://www.mwd.com.ph/index.php/mymenu-home">Read More</a> </p>
        
          
        </article>
	</section>


	
	 <section>
       
	   <article>
	   
	   
 
          <h2><a href="#">Mission</a></h2>
           <p style="    
		font-family:georgia, serif;
	  color:#381704;
	  font-size:14px;
	  letter-spacing:0.1em;
	  line-height:200%;
	  padding-top:11px;
	  ">"The association has already been an active partner of the management in realization of the water district’s objectives by being involve in various organizational activities since its inception. To date, a majority of the employees have united into a more dynamic and productive employees’ organization for the attainment of the vision/mission of a sustainable water service provider,"			-by : MCWDEAP<a href="http://www.mwd.com.ph/index.php/mymenu-home">Read More</a> </p>
        
        
         
          
        </article>
	</section>
	

      <!-- section 2 -->
      <section id="services" class="last clear">
       
      </section>
    </div>
    <!-- / content body -->
    <div class="clear"></div>
  </div>
  <div class="clear"></div>