
<!-- footer -->
<div class="wrapper row3">
  <footer id="footer">
    <p class="fl_left">Copyright &copy; 2015 - All Rights Reserved - A Thesis II research of BE4MA student <a href="#"></a></p>
    <p class="fl_right">B.S Computer Science Department - AICS Dau</p>
    <div class="clear"></div>
  </footer>
</div>