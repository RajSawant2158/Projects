# online-voting-system-qr
Online Voting System Using QR Code
