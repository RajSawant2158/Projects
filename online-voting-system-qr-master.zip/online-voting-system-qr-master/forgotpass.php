<head>


<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<title>Voting Register</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" href="css/demo.css">
		<link rel="stylesheet" href="css/sky-forms.css">
		<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
		<script type="text/javascript" src="js/jquery.pwdMeter.js"></script>
</head>

<form action="forgot.php" class="sky-form" method="post">
<div class="row">
					<section class="col col-7">
						<label class="select">
						<b>Secrete Question</b>
							<select name="question">
							<option value="What is the first name of the person you first kissed?">What is the first name of the person you first kissed?</option>
								<option value="What is the last name of the teacher who gave you your first failing grade?">What is the last name of the teacher who gave you your first failing grade?</option>
								<option value="What is the name of the place your wedding reception was held?">What is the name of the place your wedding reception was held?</option>
								<option value="What was the name of your elementary / primary school?">What was the name of your elementary / primary school?</option>
								<option value="In what city or town does your nearest sibling live?">In what city or town does your nearest sibling live?</option>
								<option value="What time of the day were you born?">What time of the day were you born?</option>
								<option value="What is your pet’s name?">What is your pet’s name?</option>
								<option value="In what year was your father born?">In what year was your father born?</option>
								
							</select>
							<i></i>
						</label>
					</section>
						
					<section class="col col-5">
						<label class="input">
							<b>Secret Answer</b>
							<input name= "answer" placeholder="Secret Answer" type="text">
							
						</label>
					</section>
					</div>
					
					<footer>
					<a href="index.php"><img src="img/arrow_left.png" width="50px"></a>
				
					<button type="submit" class="button">Submit</button>
					</footer>
</form> 